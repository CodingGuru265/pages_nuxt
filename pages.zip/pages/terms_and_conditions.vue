<template>
    <DefaultLayout>
      <TermsAndConditions />
    </DefaultLayout>
  </template>
  
  <script lang="ts" setup>
  import DefaultLayout from '~/components/Layouts/DefaultLayout.vue';
  import JoinSection from '~/components/Join/JoinSection.vue';
  import TermsAndConditions from '~/components/documentation/terms_and_conditions.vue';
  </script>
  
  <style lang="scss" module></style>
  
<template>
  <DefaultLayout>
    <PrivacyPolicySection />
  </DefaultLayout>
</template>

<script lang="ts" setup>
import DefaultLayout from '~/components/Layouts/DefaultLayout.vue';
import JoinSection from '~/components/Join/JoinSection.vue';
import PrivacyPolicySection from '~/components/documentation/privacy_policy.vue';
</script>

<style lang="scss" module></style>

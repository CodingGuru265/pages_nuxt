export function useNewsItems() {
  return [
    {
      date: '21.07.2022',
      author: 'Simon Voelk',
      title: 'Only 30 Days left till Minting! Connect your wallet!',
      text: 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas mo',
    },
    {
      date: '21.07.2022',
      author: 'Simon Voelk',
      title: '60 Days for FutureX EXPO launch date. Future is almoust here!',
      text: 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas mo',
    },
    {
      date: '21.07.2022',
      author: 'Simon Voelk',
      title: '60 Days for FutureX EXPO launch date. Future is almoust here!',
      text: 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas mo',
    },
    {
      date: '21.07.2022',
      author: 'Simon Voelk',
      title: '60 Days for FutureX EXPO launch date. Future is almoust here!',
      text: 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas mo',
    },
    {
      date: '21.07.2022',
      author: 'Simon Voelk',
      title: '60 Days for FutureX EXPO launch date. Future is almoust here!',
      text: 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas mo',
    },
    {
      date: '21.07.2022',
      author: 'Simon Voelk',
      title: '60 Days for FutureX EXPO launch date. Future is almoust here!',
      text: 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas mo',
    },
  ];
}

<template>
    <section :class="$style.section">
      <div class="row">
        <h1 style="text-align: left; margin-bottom: 20px; font-size: 30px;"><span style="color: #CFB16D;">Example Impressions</span></h1>
        <div class="row" style="margin-right: -60px;" >
          <div class="col-md-6">
              <div class="card">
              <img
                  src="@/assets/images/impressions/big_image.png"
                  alt="FUTURE Image"
                  class="custom-image"
                  style="width: 100% !important;"
              />
              </div>
          </div>
          <div class="col-md-6" >
              <div class="row">
                  <div class="col-md-6">
                      <div class="card">
                          <img
                              src="@/assets/images/impressions/small_image_1.png"
                              alt="FUTURE Image"
                              class="custom-image"
                              :class="$style['custom-image']"
                          />
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="card">
                          <img
                              src="@/assets/images/impressions/small_image_2.png"
                              alt="FUTURE Image"
                              class="custom-image"
                              :class="$style['custom-image']"
                          />
                      </div>
                  </div>
              </div>
              <div class="row" style="margin-top: 20px;">
                  <div class="col-md-6">
                      <div class="card">
                          <img
                              src="@/assets/images/impressions/small_image_3.png"
                              alt="FUTURE Image"
                              class="custom-image"
                              :class="$style['custom-image']"
                          />
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="card">
                          <img
                              src="@/assets/images/impressions/small_image_4.png"
                              alt="FUTURE Image"
                              class="custom-image"
                              :class="$style['custom-image']"
                          />
                      </div>
                  </div>
              </div>
          </div>  
        </div>
        <div class="row" style="margin-top: 20px;">
            <div class="col-md-4">
                <div class="row">
                    <div class="card">
                        <div class="col-md-12">
                            <img
                                src="@/assets/images/packages_impressions/1.png"
                                alt="FUTURE Image"
                                class="custom-image"
                                style="width: 100% !important;"
                            />
                        </div>
                        <h4 style="padding-bottom: 6px !important;">Galaxy & Planets:</h4>
                        <hr style="border: white 1px solid ; margin-right: 75%; color:white; opacity: 0.8" />
                        <p style="text-align: left;color: grey">Lorem ipsum dolor sit amet, <br>
                            consectetur adipiscing elit, sed<br> 
                            do eiusmod tempor incid
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="row">
                    <div class="card">
                        <div class="col-md-12">
                            <img
                                src="@/assets/images/packages_impressions/2.png"
                                alt="FUTURE Image"
                                class="custom-image"
                                style="width: 100% !important;"
                            />
                        </div>
                        <h4 style="padding-bottom: 6px !important;" >Smart Nations & Cities:</h4>
                        <hr style="border: white 1px solid ; margin-right: 75%; color:white; opacity: 0.8" />
                        <p style="text-align: left;color: grey">Lorem ipsum dolor sit amet, <br>
                            consectetur adipiscing elit, sed<br> 
                            do eiusmod tempor incid
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="row">
                    <div class="card">
                        <div class="col-md-12">
                            <img
                                src="@/assets/images/packages_impressions/3.png"
                                alt="FUTURE Image"
                                class="custom-image"
                                style="width: 100% !important;"
                            />
                        </div>
                        <h4 style="padding-bottom: 6px !important;">Mega Projects & Environments</h4>
                        <hr style="border: white 1px solid ; margin-right: 75%; color:white; opacity: 0.8" />
                        <p style="text-align: left;color: grey">Lorem ipsum dolor sit amet, <br>
                            consectetur adipiscing elit, sed<br> 
                            do eiusmod tempor incid
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row" style="margin-top: 20px;">
            <div class="col-md-4">
                <div class="row">
                    <div class="card">
                        <div class="col-md-12">
                            <img
                                src="@/assets/images/packages_impressions/4.png"
                                alt="FUTURE Image"
                                class="custom-image"
                                style="width: 100% !important;"
                            />
                        </div>
                        <h4 style="padding-bottom: 6px !important;">Large & Small Buildings:</h4>
                        <hr style="border: white 1px solid ; margin-right: 75%; color:white; opacity: 0.8" />
                        <p style="text-align: left;color: grey">Lorem ipsum dolor sit amet, <br>
                            consectetur adipiscing elit, sed<br> 
                            do eiusmod tempor incid
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="row">
                    <div class="card">
                        <div class="col-md-12">
                            <img
                                src="@/assets/images/packages_impressions/5.png"
                                alt="FUTURE Image"
                                class="custom-image"
                                style="width: 100% !important;"
                            />
                        </div>
                        <h4 style="padding-bottom: 6px !important;" >Booths / Shops & Stores:</h4>
                        <hr style="border: white 1px solid ; margin-right: 75%; color:white; opacity: 0.8" />
                        <p style="text-align: left;color: grey">Lorem ipsum dolor sit amet, <br>
                            consectetur adipiscing elit, sed<br> 
                            do eiusmod tempor incid
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="row">
                    <div class="card">
                        <div class="col-md-12">
                            <img
                                src="@/assets/images/packages_impressions/6.png"
                                alt="FUTURE Image"
                                class="custom-image"
                                style="width: 100% !important;"
                            />
                        </div>
                        <h4 style="padding-bottom: 6px !important;">Vehicles:</h4>
                        <hr style="border: white 1px solid ; margin-right: 75%; color:white; opacity: 0.8" />
                        <p style="text-align: left;color: grey">Lorem ipsum dolor sit amet, <br>
                            consectetur adipiscing elit, sed<br> 
                            do eiusmod tempor incid
                        </p>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </section>
  </template>
  
  <style lang="scss" module>
  
  h4 {
      text-align: left;
      padding-top: 20px;
      padding-bottom: 20px;
      font-size: 20px;
  }
  .section {
    padding-top: 5px;
    text-align: center;
    position: relative;
    max-width: 1168px;
    margin: 0 auto;
  }
  
  @media (max-width: 1800px)
  {
      /*.section{
        margin-left: 10px !important;
      }*/
  }
  
  .primaryText {
    color: $primary; /* Replace $primary with your desired primary text color */
  }
  
  .custom-image {
    width: 90% !important;
  }
  
  .heading {
    @include font-size(28px);
    @include margin-bottom(28px);
    color: #ffffff;
    font-weight: 600;
    line-height: divide(30, 28);
  }
  
  .title {
    @include font-size(45px);
    @include margin-bottom(64px);
    line-height: divide(55, 45);
    margin-left: auto;
    margin-right: auto;
    max-width: 26ch;
    text-transform: uppercase;
    margin-bottom: 00px;
  }
  </style>
  
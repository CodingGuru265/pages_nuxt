export const useNavItems = [
  {
    name: 'Home',
    to: { name: 'index' },
  },
  {
    name: 'FUTURE MULTIVERSE',
    to: { name: 'fxpo' },
  },
  {
    name: 'LAUNCH',
    to: { name: 'launch' },
  },
  {
    name: 'INITIATIVE',
    to: { name: 'quest' },
  },
  {
    name: 'Launchpad',
    to: { name: 'launchpad' },
  },
  {
    name: 'Marketplace',
    to: { name: 'marketplace' },
  },
  // {
  //   name: 'Academy',
  //   to: { name: 'index' },
  // },
  {
    name: 'Blockchain',
    to: { name: 'blockchain' },
  },
  // {
  //   name: 'About Us',
  //   to: { name: 'about-us' },
  // },
  // {
  //   name: 'Guidebook',
  //   to: { name: 'guidebook' },
  // },
  {
    name: 'Grace AI',
    to: { name: 'grace-ai' },
  },
];
